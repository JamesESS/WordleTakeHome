const AWS = require('aws-sdk');

AWS.config.update({ region: 'us-east-1' }); // Replace with your desired AWS region

const dynamodb = new AWS.DynamoDB.DocumentClient();
const tableName = 'random_words';

exports.handler = async (event) => {
  try {
    const params = {
      TableName: tableName,
    };

    const { Item } = await dynamodb.scan(params).promise();

    if (!Item || !Item.word) {
      return {
        statusCode: 404,
        body: 'Word not found',
      };
    }

    return {
      statusCode: 200,
      body: Item.word,
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: 'Internal Server Error',
    };
  }
};
